const firebaseConfig = {
    apiKey: "AIzaSyDWiBGzd1SpTvsH5S5MzYVXgAXWQccQ3fU",
    authDomain: "remoteprojectteammanager.firebaseapp.com",
    databaseURL: "https://remoteprojectteammanager.firebaseio.com",
    projectId: "remoteprojectteammanager",
    storageBucket: "remoteprojectteammanager.appspot.com",
    messagingSenderId: "238444416696",
    appId: "1:238444416696:web:f53c757deab6af0605ee4d",
    measurementId: "G-F1QWD0EXSM"
  };

  firebase.initializeApp(firebaseConfig);