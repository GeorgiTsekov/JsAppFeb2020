import user from './user.js';
import post from './post.js';

export default {
    user,
    post
}